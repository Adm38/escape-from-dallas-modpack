# IMPORTANT
# PLEASE READ THE MOD PAGE FOR THE MOST UP TO DATE INFORMATION!
# tbh I hardly update this so please check the mod page for info/faq/questions!
#
#

# SWAG + Donuts
![Version: 3.3.0](https://img.shields.io/badge/Version-3.3.0-informational?style=flat-square)

**All credit goes to Props, creator of SWAG and DONUTS**

---

All mod info can be found on the mod page: https://hub.sp-tarkov.com/files/file/878-swag-donuts-dynamic-spawn-waves-and-custom-spawn-points/
