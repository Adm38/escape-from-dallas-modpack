export enum MPTMatchEndSessionMessage {
    HOST_SHUTDOWN_MESSAGE = "host-shutdown",
    PING_TIMEOUT_MESSAGE = "ping-timeout",
    NO_PLAYERS_MESSAGE = "no-players"
}
