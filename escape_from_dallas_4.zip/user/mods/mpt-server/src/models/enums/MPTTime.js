"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MPTTime = void 0;
var MPTTime;
(function (MPTTime) {
    MPTTime[MPTTime["CURR"] = 0] = "CURR";
    MPTTime[MPTTime["PAST"] = 1] = "PAST";
})(MPTTime || (exports.MPTTime = MPTTime = {}));
//# sourceMappingURL=MPTTime.js.map