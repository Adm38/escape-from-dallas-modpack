"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MPTSide = void 0;
var MPTSide;
(function (MPTSide) {
    MPTSide[MPTSide["PMC"] = 0] = "PMC";
    MPTSide[MPTSide["Savage"] = 1] = "Savage";
})(MPTSide || (exports.MPTSide = MPTSide = {}));
//# sourceMappingURL=MPTSide.js.map