export interface IMPTConfigServer {
    giftedItemsLoseFIR: boolean;
}
