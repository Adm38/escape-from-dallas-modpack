export interface IMPTRaidSpawnpointResponse {
    spawnpoint: string;
}
