export type IMPTSenditemAvailablereceiversResponse = Record<string, string>;
