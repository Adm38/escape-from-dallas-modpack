export interface IMPTRaidJoinResponse {
    serverId: string;
    timestamp: string;
    expectedNumberOfPlayers: number;
    gameVersion: string;
    mptVersion: string;
}
