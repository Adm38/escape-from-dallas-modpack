export interface IMPTRaidServerIdRequestData {
    serverId: string;
}
