export interface IMPTRaidLeaveRequestData {
    serverId: string;
    profileId: string;
}
