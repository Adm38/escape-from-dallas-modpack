export interface IMPTUpdateSethostRequestData {
    serverId: string;
    ip: string;
    port: number;
}
