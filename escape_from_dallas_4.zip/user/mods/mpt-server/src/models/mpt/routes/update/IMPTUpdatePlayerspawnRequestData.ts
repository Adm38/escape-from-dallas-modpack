export interface IMPTUpdatePlayerspawnRequestData {
    serverId: string;
    profileId: string;
    groupId: string;
}
