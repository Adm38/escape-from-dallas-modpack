export interface IMPTPlayer {
    groupId: string;
    isDead: boolean;
}
